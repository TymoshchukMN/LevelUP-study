﻿namespace HW4
{
    /// <summary>
    /// Перечисоение валюты в стране
    /// </summary>
    enum CurencyList
    {
        none = 0,
        dollar = 1,         // USA = 1
        Franc = 2,          // France = 2
        LiraItaliana = 3,   // Italy = 3
        Euro = 4,           // Greece = 4
        złoty  = 5          // Poland = 5
    }
}
