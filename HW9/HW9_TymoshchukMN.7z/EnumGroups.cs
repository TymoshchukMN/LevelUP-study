﻿namespace HW9
{
    /// <summary>
    /// Перечисление студенческих групп
    /// </summary>
    enum EnumGroups
    {
        none    = 0,
        finance = 98,
        math    = 99
    }
}
