﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_13
{
    enum Symbols : ushort
    {
        none = 0,
        point = 46,
        symbolType1 = 176,
        symbolType2 = 42

    }
}
