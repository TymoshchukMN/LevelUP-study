﻿namespace HW9
{
    /// <summary>
    /// Перечисление студенческих групп
    /// </summary>
    enum GroupsName: ushort
    {
        none    = 0,
        finance = 98,
        math    = 99
    }
}
