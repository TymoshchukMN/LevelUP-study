﻿namespace HW_13
{
    /// <summary>
    /// Перечислиение на сколько градусов 
    /// выполняется вращение фигуры
    /// </summary>
    public enum RotatorEnum
    {
        none,
        rotate_90,
        rotate_180
    }
}
