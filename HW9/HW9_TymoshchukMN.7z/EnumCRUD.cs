﻿namespace HW9
{
    /// <summary>
    /// CRUD операции
    /// </summary>
    enum EnumCRUD
    {
        none    = 0,
        create  = 97,   // 1
        read    = 98,   // 2
        update  = 99,  // 3
        delete  = 100   // 4
    }
}
