﻿namespace HW4
{
    ///<summary>
    ///Перечисление задач в проекте для запуска
    ///</summary>
    enum TasksList: int
    {
        none = 0,
        task1 = 1,
        task2 = 2
    }
}
