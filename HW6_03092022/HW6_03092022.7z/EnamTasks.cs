﻿/// <summary>
/// Перечисление задачи для выполнения
/// </summary>
enum TaskNumber
{
    none = 0,
    Firts  = 97,
    Second = 98,
    Third = 99,
    Fotrh = 100
}

