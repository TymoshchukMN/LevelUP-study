﻿/// <summary>
/// Задачи для запуска
/// </summary>
internal enum EnumTasks
{
    none    = 0,
    first   = 97,
    second  = 98,
    third   = 99,
    fourth  = 100

}

