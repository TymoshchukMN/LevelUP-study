﻿/// <summary>
/// Направление смещения элементов массива (Задача 2)
/// </summary>
enum EnumDirectionOffset
{
    none    = 0,
    left    = 37,
    right   = 39
}

