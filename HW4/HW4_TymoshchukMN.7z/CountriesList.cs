﻿namespace HW4
{
    ///<summary>
    ///Перечисление сран, доступных для полета
    ///</summary>
    enum CountriesList
    {
        none = 0,
        USA = 1,
        France = 2,
        Italy = 3,
        Greece = 4,
        Poland = 5
    }
}
