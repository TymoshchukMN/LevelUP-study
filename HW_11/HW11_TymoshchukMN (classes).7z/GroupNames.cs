﻿////////////////////////////////////////////
// Author : Tymoshchuk Maksym
// Created On : 17/11/2022
// Last Modified On : 
// Description: Enum names of groups
// Project: HW_11
////////////////////////////////////////////

namespace HW_11
{
    enum GroupNames : ushort
    {
        Finance = 0,
        Mathematics = 1,
        Phylosophy = 2
    }
}