﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HW9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // количество студентов (по умолчанию) в структуре студенты  
            const ushort COUNT_STUDENTS = 30;

            #region инициализация и заполнение

            // struct студентов
            Students[] students = new Students[COUNT_STUDENTS];

            // struct групп студентов
            Groups univercityGroups = new Groups();


            // инициализация группы студентов "финансы"
            univercityGroups.financeGroup = new Students[COUNT_STUDENTS];

            // заполнение группы студентов "финансы"
            CustomFunctions.FillStudentsAuto(students, COUNT_STUDENTS);

            // присвоение структуре групп (контейнеру) группы студентов (агрегата)
            univercityGroups.financeGroup = students;

            // инициализация группы студентов "математика"
            univercityGroups.mathGroup = new Students[COUNT_STUDENTS];

            // заполнение группы студентов "математика"
            CustomFunctions.FillStudentsAuto(students, COUNT_STUDENTS);

            // присвоение структуре групп (контейнеру) группы студентов (агрегата)
            univercityGroups.mathGroup = students;

            #endregion инициализация и заполнение

            #region CRUD

            #region BANNER

            Console.WriteLine("Выберите тип операции:\n" +
                "\n\t1. create" +
                "\n\t2. read" +
                "\n\t3. update" +
                "\n\t4. delete");

            #endregion BANNER

            // преобразуем выбор пользователя  в enum
            EnumCRUD userChoise = (EnumCRUD)Console.ReadKey().Key;

            Console.Clear();

            switch ((EnumCRUD)userChoise)
            {
                #region создать (CREATE)

                case EnumCRUD.create:

                    // банер запроса количества студентов
                    UI.PrintRequestCountStudent();

                    // количество студентов к добавлению
                    ushort countAddStudents;
                    countAddStudents = ushort.Parse(Console.ReadLine());

                    // банер выбора группы
                    UI.PrintRequestGroup();

                    ushort groupForAdd;
                    groupForAdd = ushort.Parse(Console.ReadLine());

                    Console.Clear();

                    // получение группы для добавления на основе Енама                  
                    Students[] choisedGroup = CustomFunctions.GetGroup(
                            ref univercityGroups, groupForAdd);

                    // проверка можно ли добавить столько студентов
                    bool isAdditionAvailable;
                    isAdditionAvailable = CustomFunctions.CheckIsAddStudntAllow(
                            ref choisedGroup, countAddStudents);

                    if (isAdditionAvailable)
                    {
                        // создание карточки студента
                        CustomFunctions.CreateStudent(ref choisedGroup,
                                countAddStudents);

                        // печать введенных студентов
                        UI.PrintAddedStudents(ref choisedGroup, countAddStudents);
                    }
                    else
                    {
                        // печать баннера, что добавить нельзя
                        UI.PrintDenyAddBanner(countAddStudents, ref choisedGroup,
                                CustomFunctions.MAX_STUDENTS_COUNT);
                    }

                    break;

                #endregion создать (CREATE)

                #region READ

                case EnumCRUD.read:



                    Console.Clear();

                    // банер выбора группы
                    UI.PrintRequestGroup();

                    groupForAdd = ushort.Parse(Console.ReadLine());

                    Console.Clear();

                    // получение группы для добавления на основе Енама                  
                    choisedGroup = CustomFunctions.GetGroup(
                            ref univercityGroups, groupForAdd);

                    UI.PrintExistingRB(ref students, --groupForAdd);

                    // Запрос номера зачетки для поиска 
                    UI.PrintRequestRecordBookForSearch();

                    // переменная для хранения номера учетки
                    string recordBook;

                    recordBook = Console.ReadLine();


                    // вызов функции на чтение данных студента по номеру зачетки
                    CustomFunctions.ReadRequest(ref choisedGroup, recordBook);

                    break;

                #endregion READ

                #region UPDATE

                case EnumCRUD.update:

                    // банер выбора группы
                    UI.PrintRequestGroup();

                    groupForAdd = ushort.Parse(Console.ReadLine());

                    // получение группы для добавления на основе Енама                  
                    choisedGroup = CustomFunctions.GetGroup(
                            ref univercityGroups, groupForAdd);

                    // печать карточек студентов в группе
                    UI.PrintGroupContent(ref choisedGroup, groupForAdd);

                    // запро номер учеки студента для изменения
                    UI.PrintRequestRecordBook();

                    recordBook = Console.ReadLine();

                    #region проверка номера зачетки


                    bool isRBCorrect;

                    // вызов функ-ии на проверку номера зачетки
                    isRBCorrect = CustomFunctions.IsRecordBookCorrect(recordBook);

                    bool isRBexist;

                    isRBexist = CustomFunctions.IsRecordBookExist(ref choisedGroup,
                                    recordBook, students.Count());

                    if (!isRBexist)
                    {
                        // печать ошибки, что такого номера нет
                        UI.PrintErrorRBNOTExist();

                        do
                        {
                            UI.PrintRequestRecordBook();
                            recordBook = Console.ReadLine();

                            isRBexist = CustomFunctions.IsRecordBookExist(ref choisedGroup,
                                    recordBook, students.Count());

                        } while (!isRBexist);
                    }

                    // полчение индекса под которым хранится карточка студента
                    int indexStudent = CustomFunctions.GetStudentIndex(
                            ref choisedGroup, recordBook);

                    #endregion проверка номера зачетки

                    // запрос поля для изменния
                    UI.RequestFieldForChange();

                    // полчение параметра к изменению
                    ushort.TryParse(Console.ReadLine(), out ushort fieldNum);

                    // запрос нового значения для поля
                    UI.RequestNewVol();
                    string newVol = Console.ReadLine();

                    Console.WriteLine("\nКарточка до изменения");
                    UI.PrintUserCard(ref choisedGroup, indexStudent);

                    // вызов функции на изменение
                    CustomFunctions.UpdateStudentData(ref choisedGroup, 
                            recordBook, fieldNum, newVol, indexStudent);
                    

                    Console.WriteLine("\nКарточка после изменения");
                    UI.PrintUserCard(ref choisedGroup, indexStudent);

                    Console.ReadKey();

                    // вызов функции на чтение данных студента по номеру зачетки
                    //CustomFunctions.ReadRequest(ref choisedGroup, recordBook);

                    break;

                #endregion UPDATE

                #region DELETE

                case EnumCRUD.delete:

                    // банер выбора группы
                    UI.PrintRequestGroup();

                    groupForAdd = ushort.Parse(Console.ReadLine());

                    // получение группы для добавления на основе Енама                  
                    choisedGroup = CustomFunctions.GetGroup(
                            ref univercityGroups, groupForAdd);

                    // печать карточек студентов в группе
                    UI.PrintGroupContent(ref choisedGroup, groupForAdd);

                    // запроc номер учеки студента для изменения
                    UI.PrintRequestRecordBook();

                    recordBook = Console.ReadLine();

                    #region проверка номера зачетки

                    // вызов функ-ии на проверку номера зачетки
                    isRBCorrect = CustomFunctions.IsRecordBookCorrect(recordBook);

                    isRBexist = CustomFunctions.IsRecordBookExist(ref choisedGroup,
                                    recordBook, students.Count());

                    if (!isRBexist)
                    {
                        // печать ошибки, что такого номера нет
                        UI.PrintErrorRBNOTExist();

                        do
                        {
                            UI.PrintRequestRecordBook();
                            recordBook = Console.ReadLine();

                            isRBexist = CustomFunctions.IsRecordBookExist(ref choisedGroup,
                                    recordBook, students.Count());

                        } while (!isRBexist);
                    }

                    // полчение индекса под которым хранится карточка студента
                    indexStudent = CustomFunctions.GetStudentIndex(
                            ref choisedGroup, recordBook);

                    #endregion проверка номера зачетки

                    CustomFunctions.DeleteElement(ref choisedGroup, indexStudent);

                    // печать карточек студентов в группе
                    UI.PrintGroupContent(ref choisedGroup, groupForAdd);

                    break;

                #endregion DELETE

            }

            #endregion CRUD


            Console.ReadKey();
        }
    }
    
}
